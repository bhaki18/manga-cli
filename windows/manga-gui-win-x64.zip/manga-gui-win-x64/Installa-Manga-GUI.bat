@echo off
chcp 65001 >nul
title Manga GUI - Installazione per Windows

echo ========================================================
echo               MANGA GUI - INSTALLER WINDOWS
echo ========================================================
echo.
echo  Avvio installazione di Manga GUI sul tuo computer...
echo.

set "SCRIPT_DIR=%~dp0"

if exist "%SCRIPT_DIR%MangaGui-Setup.exe" (
    echo  Avvio del programma di installazione guidata...
    start "" "%SCRIPT_DIR%MangaGui-Setup.exe"
    exit /b 0
)

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\MangaGui"

echo  [1/4] Creazione directory di installazione...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo  [2/4] Copia dei file dell'applicazione...
xcopy /E /I /Y /Q "%SCRIPT_DIR%*" "%INSTALL_DIR%\" >nul

echo  [3/4] Creazione collegamenti Desktop e Menu Start...
set "TARGET_EXE=%INSTALL_DIR%\MangaGui.exe"
set "ICON_FILE=%INSTALL_DIR%\manga-gui.ico"
if not exist "%ICON_FILE%" set "ICON_FILE=%TARGET_EXE%"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws = New-Object -ComObject WScript.Shell; " ^
  "$desk = [Environment]::GetFolderPath('Desktop'); " ^
  "$s1 = $ws.CreateShortcut(\"$desk\Manga GUI.lnk\"); " ^
  "$s1.TargetPath = '%TARGET_EXE%'; " ^
  "$s1.WorkingDirectory = '%INSTALL_DIR%'; " ^
  "$s1.IconLocation = '%ICON_FILE%,0'; " ^
  "$s1.Description = 'Manga GUI - Downloader, Streamer e Reader'; " ^
  "$s1.Save(); " ^
  "$startMenu = [Environment]::GetFolderPath('Programs'); " ^
  "$s2 = $ws.CreateShortcut(\"$startMenu\Manga GUI.lnk\"); " ^
  "$s2.TargetPath = '%TARGET_EXE%'; " ^
  "$s2.WorkingDirectory = '%INSTALL_DIR%'; " ^
  "$s2.IconLocation = '%ICON_FILE%,0'; " ^
  "$s2.Description = 'Manga GUI - Downloader, Streamer e Reader'; " ^
  "$s2.Save();"

echo  [4/4] Registrazione in Windows...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MangaGui" /v "DisplayName" /t REG_SZ /d "Manga GUI" /f >nul 2>nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MangaGui" /v "DisplayIcon" /t REG_SZ /d "%ICON_FILE%" /f >nul 2>nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MangaGui" /v "InstallLocation" /t REG_SZ /d "%INSTALL_DIR%" /f >nul 2>nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MangaGui" /v "Publisher" /t REG_SZ /d "Manga GUI" /f >nul 2>nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\MangaGui" /v "UninstallString" /t REG_SZ /d "cmd /c rmdir /s /q \"%INSTALL_DIR%\"" /f >nul 2>nul

echo.
echo ========================================================
echo  [OK] Installazione completata con successo!
echo  Icona creata sul Desktop e nel Menu Start.
echo ========================================================
echo.
echo  Avvio di Manga GUI...
start "" "%TARGET_EXE%"
