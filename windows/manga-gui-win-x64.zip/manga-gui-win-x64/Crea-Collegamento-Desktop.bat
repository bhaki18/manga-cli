@echo off
chcp 65001 >nul
title Manga GUI - Creazione Collegamento Desktop

echo.
echo =======================================================
echo          MANGA GUI - CREAZIONE COLLEGAMENTO
echo =======================================================
echo.
echo Creazione dell'icona di Manga GUI sul tuo Desktop in corso...

set "SCRIPT_DIR=%~dp0"
set "TARGET_EXE=%SCRIPT_DIR%MangaGui.exe"
set "ICON_FILE=%SCRIPT_DIR%manga-gui.ico"
set "DESKTOP_DIR=%USERPROFILE%\Desktop"
set "SHORTCUT_PATH=%DESKTOP_DIR%\Manga GUI.lnk"

if not exist "%ICON_FILE%" set "ICON_FILE=%TARGET_EXE%"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT_PATH%'); $s.TargetPath = '%TARGET_EXE%'; $s.WorkingDirectory = '%SCRIPT_DIR%'; $s.IconLocation = '%ICON_FILE%,0'; $s.Description = 'Manga GUI - Downloader, Streamer e Reader'; $s.Save()"

if exist "%SHORTCUT_PATH%" (
    echo.
    echo  [OK] Collegamento creato con successo sul Desktop!
    echo.
    echo  Ora puoi avviare l'app semplicemente cliccando
    echo  sull'icona di Manga GUI presente sul tuo Desktop.
    echo.
) else (
    echo.
    echo  [ERRORE] Impossibile creare il collegamento automaticamente.
    echo.
)

echo Premi un tasto per uscire...
pause >nul
